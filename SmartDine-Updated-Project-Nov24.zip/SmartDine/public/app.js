const params = new URLSearchParams(location.search);
const tableNo = params.get("table") || "1";
document.getElementById("table-label").textContent = `TABLE ${tableNo}`;
let menu = [], cart = {}, activeCategory = "All", currentOrder = null;
const money = n => `₹${Number(n).toFixed(0)}`;
const $ = id => document.getElementById(id);
async function loadMenu(){
  menu = await fetch("/api/menu").then(r=>r.json());
  const cats = ["All",...new Set(menu.map(x=>x.category))];
  $("categories").innerHTML = cats.map(c=>`<button class="cat ${c===activeCategory?"active":""}" data-cat="${c}">${c}</button>`).join("");
  document.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.cat;renderMenu();});
  renderMenu();
}
function renderMenu(){
  const term=$("search").value.toLowerCase();
  const filtered=menu.filter(x=>(activeCategory==="All"||x.category===activeCategory)&&(x.name.toLowerCase().includes(term)||x.description.toLowerCase().includes(term)));
  const photos={
  "Paneer Tikka":"photo-1567188040759-fb8a883dc6d8",
  "Crispy Corn":"photo-1528735602780-2552fd46c7af",
  "Veg Spring Rolls":"photo-1544025162-d76694265947",
  "Classic Margherita":"photo-1579751626657-72bc17010498",
  "Farmhouse Pizza":"photo-1513104890138-7c749659a591",
  "Creamy Alfredo Pasta":"photo-1473093295043-cdd812d0e601",
  "Veg Biryani":"photo-1563379091339-03246963d96c",
  "Paneer Butter Masala":"photo-1585937421612-70a008356fbe",
  "Chocolate Brownie":"photo-1606313564200-e75d5e30476c",
  "Gulab Jamun":"photo-1666190092159-3e9c6f2f1b2a",
  "Fresh Lime Soda":"photo-1513558161293-ccadaeabf4b5",
  "Cold Coffee":"photo-1461023058943-07fcbe16d735"
};
const photoUrl=name=>`https://images.unsplash.com/${photos[name]||"photo-1540189549336-e6e99c3679fe"}?auto=format&fit=crop&w=900&q=85`;
$("menu-grid").innerHTML=filtered.length?filtered.map(x=>`<article class="menu-card"><div class="dish-art"><img src="${photoUrl(x.name)}" alt="${x.name}" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('photo-fallback')"><span>${x.category}</span></div><div class="dish-info"><h3>${x.name}</h3><p>${x.description}</p><div class="dish-bottom"><strong>${money(x.price)}</strong><button class="add-btn" data-add="${x.id}">＋ Add</button></div></div></article>`).join(""):`<p class="empty">No dishes found. Try another search.</p>`;
  document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>addItem(Number(b.dataset.add)));
  document.querySelectorAll("[data-cat]").forEach(b=>b.classList.toggle("active",b.dataset.cat===activeCategory));
}
function addItem(id){cart[id]=(cart[id]||0)+1;updateCart();toast("Added to your cart");}
function updateCart(){
  const qty=Object.values(cart).reduce((a,b)=>a+b,0);
  const total=menu.reduce((s,x)=>s+x.price*(cart[x.id]||0),0);
  $("cart-count").textContent=`${qty} item${qty===1?"":"s"}`;$("cart-total").textContent=money(total);
  $("cart-dock").classList.toggle("show",qty>0);$("modal-total").textContent=money(total);
}
function renderCart(){
  const chosen=menu.filter(x=>cart[x.id]);
  $("cart-lines").innerHTML=chosen.length?chosen.map(x=>`<div class="cart-line"><div><strong>${x.name}</strong><small>${money(x.price)} each</small></div><div class="quantity"><button data-minus="${x.id}">−</button><b>${cart[x.id]}</b><button data-plus="${x.id}">＋</button></div><strong>${money(x.price*cart[x.id])}</strong></div>`).join(""):`<p>Your cart is empty.</p>`;
  document.querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>{const id=b.dataset.minus;cart[id]--;if(cart[id]<=0)delete cart[id];renderCart();updateCart();});
  document.querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>{cart[b.dataset.plus]++;renderCart();updateCart();});
  updateCart();
}
$("open-cart").onclick=()=>{$("cart-modal").hidden=false;renderCart();};
$("close-cart").onclick=()=>$("cart-modal").hidden=true;
$("cart-modal").onclick=e=>{if(e.target.id==="cart-modal")$("cart-modal").hidden=true;};
$("search").addEventListener("input",renderMenu);
$("place-order").onclick=async()=>{
  const items=Object.entries(cart).map(([id,quantity])=>({id:Number(id),quantity}));
  if(!items.length)return toast("Add something to your cart first.");
  $("place-order").disabled=true;$("place-order").textContent="Sending order...";
  try{
    const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tableNo,items,note:$("order-note").value})});
    const data=await res.json();if(!res.ok)throw new Error(data.error||"Could not place order");
    currentOrder=data.id;cart={};$("cart-modal").hidden=true;updateCart();showStatus(data.id);toast("Order placed successfully!");
  }catch(e){toast(e.message);}finally{$("place-order").disabled=false;$("place-order").innerHTML='Place order <span>→</span>';}
};
async function showStatus(id){
  const o=await fetch(`/api/orders/${id}`).then(r=>r.json());if(o.error)return;
  $("order-status").hidden=false;$("status-order-id").textContent=`#${o.id}`;$("status-table").textContent=`Table ${o.table_no} · ${o.items.map(i=>`${i.quantity}× ${i.item_name}`).join(", ")}`;
  $("status-chip").textContent=o.status;$("status-message").textContent=({Placed:"Your order has been sent to the kitchen.",Preparing:"The kitchen is preparing your food.",Ready:"Your order is ready. The team will bring it to you.",Served:"Enjoy your meal!",Cancelled:"This order was cancelled."})[o.status]||"Order update";
  const steps=["Placed","Preparing","Ready","Served"],idx=steps.indexOf(o.status);
  $("status-order").querySelectorAll(".status-track span").forEach((s,i)=>s.classList.toggle("done",idx>=i));
}
$("refresh-status").onclick=()=>currentOrder&&showStatus(currentOrder);
setInterval(()=>currentOrder&&showStatus(currentOrder),12000);
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("visible");setTimeout(()=>t.classList.remove("visible"),2200);}
loadMenu();updateCart();

const quiz=[
 {q:"Which spice gives biryani its golden colour?",a:["Turmeric","Cinnamon","Clove"],correct:0,why:"Turmeric gives food its warm golden-yellow colour."},
 {q:"Which of these is made from chickpeas?",a:["Hummus","Pesto","Salsa"],correct:0,why:"Hummus is a creamy dip made mainly from chickpeas."},
 {q:"What is the main ingredient in guacamole?",a:["Avocado","Cucumber","Peas"],correct:0,why:"Avocado gives guacamole its creamy texture."}
];let qi=0,answered=false;
function showQuiz(){const q=quiz[qi];$("quiz-count").textContent=`0${qi+1} / 03`;$("quiz-question").textContent=q.q;$("quiz-options").innerHTML=q.a.map((a,i)=>`<button class="quiz-option" data-answer="${i}">${a}</button>`).join("");$("quiz-feedback").textContent="Pick your answer to play.";$("next-question").hidden=true;answered=false;document.querySelectorAll("[data-answer]").forEach(b=>b.onclick=()=>{if(answered)return;answered=true;const ok=Number(b.dataset.answer)===q.correct;b.classList.add(ok?"correct":"wrong");$("quiz-feedback").textContent=(ok?"Correct! ":"Not quite. ")+q.why;if(!ok)document.querySelector(`[data-answer="${q.correct}"]`).classList.add("correct");$("next-question").hidden=false;});}
$("next-question").onclick=()=>{qi=(qi+1)%quiz.length;showQuiz();};showQuiz();


// Educational food-safety guidance. This is not a laboratory test or adulteration detector.
const safetyGuidance = {
  normal: {title:"No obvious warning sign selected", body:"A normal appearance does not prove that food is safe or free from adulteration. Check the source, packaging, storage conditions and official product information."},
  packaging: {title:"Do not use damaged or tampered packaging", body:"Avoid buying or consuming the product. Keep the packaging and bill, note the batch details and contact the seller or the relevant food-safety authority."},
  date: {title:"Check traceability details", body:"Do not consume food that is past its expiry / use-by date. If required dates, batch number or manufacturer details are missing, avoid the product and report the concern."},
  appearance: {title:"Treat unusual appearance as a warning sign", body:"Do not taste-test it. Keep the product separate, retain its packaging and seek advice from the seller or food-safety authority. Appearance alone cannot confirm adulteration."},
  smell: {title:"Do not taste food with an unusual smell", body:"Stop using it and discard or safely isolate it. Preserve product details if you suspect a safety issue. Smell alone cannot identify a specific adulterant."},
  illness: {title:"Prioritise health and report the concern", body:"Stop eating the food. Seek medical help promptly if symptoms are severe or persistent. Preserve the packaging / bill and report suspected food poisoning to the appropriate authority."}
};
const safetyButton = document.getElementById("safety-check");
if (safetyButton) safetyButton.onclick = () => {
  const sign = document.getElementById("safety-sign").value;
  const food = document.getElementById("safety-food").selectedOptions[0].text;
  const result = safetyGuidance[sign];
  document.getElementById("safety-result").innerHTML = `<strong>${result.title}</strong><p>Food category: ${food}</p><p>${result.body}</p><small>For confirmation, use an authorised food-testing laboratory. Never rely on this website to decide that food is safe to eat.</small>`;
};
